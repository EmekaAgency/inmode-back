ajouter produits
enlever produits
aperçu des stocks (google shopping)
login - mail
login - password
remplacer le ico cart par un pen
urotsukidoji