<?php
    function get_connection(){
        // echo '<p>get_connection()</p>';
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "inmode";
        $port = 3306;

        // Create connection
//        $conn = new mysqli($servername, $username, $password, $dbname, $port);
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            return -1;
        } else {
            $conn->query('SET NAMES utf8');
            return $conn;
        }
    };
?>