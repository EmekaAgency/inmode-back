<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
    <head>
        <title>InMode - France</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="description" content="Festival de films d'auteurs">
        <meta name="keywords" content="festival, festivals, films, film, auteur, auteurs">
        <meta name="author" content="Maël FALLET">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="./main.css">
    </head>
    <body>
        <main>
            <div class="basic-test-part">
                <button type="button" onclick="test_no_action()">no_action</button>
                <button type="button" onclick="test_empty_action()">empty_action</button>
                <button type="button" onclick="test_signup_wrong()">signup_wrong</button>
                <button type="button" onclick="test_signup_missing()">signup_missing</button>
                <button type="button" onclick="test_signup_basic()">signup_basic</button>
                <button type="button" onclick="test_login_wrong()">login_wrong</button>
                <button type="button" onclick="test_login_missing()">login_missing</button>
                <button type="button" onclick="test_login_basic()">login_basic</button>
                <button type="button" onclick="test_reset()">reset</button>
                <p>response => <span id="test-result-response"></span>
            </div>
            <div class="signup-part">
                <div id="demo"></div>
                <div class="basic-part">
                    <h2>SIGNUP BASE</h2>
                    <form id="form-signup-basic">
                        <input name="action" value="signup"hidden/>
                        <input name="type" value="basic"hidden/>
                        <input name="firstname" id="signup-firstname" type="text" placeholder="Prénom"/>
                        <label for="firstname" id="signup-firstname-label"></label>
                        <input name="lastname" id="signup-lastname" type="text" placeholder="Nom"/>
                        <label for="lastname" id="signup-lastname-label"></label>
                        <input name="email" id="signup-email" type="email" placeholder="Mail"/>
                        <label for="email" id="signup-email-label"></label>
                        <input name="password" id="signup-password" type="password" placeholder="Mot de passe"/>
                        <label for="password" id="signup-password-label"></label>
                        <button id="signup-basic" type="submit" class="submit-button">Submit</button>
                    </form>
                    <button id="signup-basic-reset" class="submit-button" onclick="signup_reset('basic')">Reset</button>
                    <p>status => <span id="signup-basic-result-status"></span>
                    <p>reason => <span id="signup-basic-result-reason"></span>
                    <p>message => <span id="signup-basic-result-message"></span>
                    <p>query => <span id="signup-basic-result-query"></span>
                    <p>type => <span id="signup-basic-result-type"></span>
                    <p>firstname => <span id="signup-basic-result-firstname"></span></p>
                    <p>lastname => <span id="signup-basic-result-lastname"></span></p>
                    <p>email => <span id="signup-basic-result-email"></span></p>
                    <p>password => <span id="signup-basic-result-password"></span></p>
                    <p>id => <span id="signup-basic-result-id"></span></p>
                </div>
            </div>
            <div class="login-part">
                <div class="basic-part">
                    <h2>LOGIN BASE</h2>
                    <form id="form-login-basic">
                        <input name="email" id="login-email" type="email" placeholder="Mail"/>
                        <label for="email" id="login-email-label"></label>
                        <input name="password" id="login-password" type="password" placeholder="Mot de passe"/>
                        <label for="password" id="login-password-label"></label>
                        <button id="login-basic" type="submit" class="submit-button">Submit</button>
                    </form>
                    <button id="login-basic-reset" class="submit-button" onclick="login_reset('basic')">Reset</button>
                    <p>status => <span id="login-basic-result-status"></span>
                    <p>reason => <span id="login-basic-result-reason"></span>
                    <p>message => <span id="login-basic-result-message"></span>
                    <p>query => <span id="login-basic-result-query"></span>
                    <p>result => <span id="login-basic-result-result"></span>
                </div>
            </div>
        </main>
        <footer>

        </footer>
        <script src="./script.js"></script>
    </body>
</html>