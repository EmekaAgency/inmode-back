const url_test  = "./back/index.php";
const default_data = {'action':'', 'data': ''};

const to_reset_signup = [
    'status',
    'reason',
    'message',
    'type',
    'firstname',
    'lastname',
    'email',
    'password',
    'id'
];

const to_reset_login = [
    'status',
    'reason',
    'message',
    'query',
    'result'
];

function signup(type) {
    let i = 0;
    if(document.getElementById("signup-firstname").value == ''){
        document.getElementById("signup-firstname-label").innerHTML = '<p class="error">Erreur</p>';
        ++i;
    }
    if(document.getElementById("signup-lastname").value == ''){
        document.getElementById("signup-lastname-label").innerHTML = '<p class="error">Erreur</p>';
        ++i;
    }
    if(document.getElementById("signup-email").value == '' || !is_mail(document.getElementById("signup-email").value)){
        document.getElementById("signup-email-label").innerHTML = '<p class="error">Erreur</p>';
        ++i;
    }
    if(document.getElementById("signup-password").value == ''){
        document.getElementById("signup-password-label").innerHTML = '<p class="error">Erreur</p>';
        ++i;
    }
    if(i > 0){return false;}
    var data = {
        'action': 'signup',
        'data': {
            'type': type
        }
    };
    if(type == 'basic') {

        data.data.firstname = document.getElementById("signup-firstname").value;
        data.data.lastname = document.getElementById("signup-lastname").value;
        data.data.email = document.getElementById("signup-email").value;
        data.data.password = document.getElementById("signup-password").value;
    }
    _AJAX(data, "POST");
}

function login(type) {
    let i = 0;
    if(document.getElementById("login-email").value == '' || !is_mail(document.getElementById("login-email").value)){
        document.getElementById("login-email-label").innerHTML = '<p class="error">Erreur</p>';
        ++i;
    }
    if(document.getElementById("login-password").value == ''){
        document.getElementById("login-password-label").innerHTML = '<p class="error">Erreur</p>';
        ++i;
    }
    var data = {
        'action': 'login',
        'data': {
            'type': type
        }
    };
    if(i > 0){return false;}
    if(type == 'basic') {
        data.data.email = document.getElementById("login-email").value;
        data.data.password = document.getElementById("login-password").value;
    }
    _AJAX(data, "POST");
}

function test_no_action() {
    _AJAX({
        'type': 'test',
        'data': {
            'type': 'basic',
            'firstname': 'Prénom',
            'lastname': 'Nom',
            'email': 'mail',
            'password': 'pass'
        }
    });
}

function test_empty_action() {
    _AJAX({
        'type': 'test',
        'action': '',
        'data': {
            'type': 'basic',
            'firstname': 'Prénom',
            'lastname': 'Nom',
            'email': 'mail',
            'password': 'pass'
        }
    });
}

function test_signup_wrong() {
    _AJAX({
        'type': 'test',
        'action': 'signup',
        'data': {
            'type': 'basic',
            'firstname': '2',
            'lastname': 'Nom',
            'email': 'mail',
            'password': 'pass'
        }
    });
}

function test_signup_missing() {
    _AJAX({
        'type': 'test',
        'action': 'signup',
        'data': {
            'type': 'basic',
            'lastname': 'Nom',
            'email': 'mail',
            'password': 'pass'
        }
    });
}

function test_signup_basic() {
    _AJAX({
        'type': 'test',
        'action': 'signup',
        'data': {
            'type': 'basic',
            'firstname': 'Prénom',
            'lastname': 'Nom',
            'email': 'mail@mail.fr',
            'password': 'pass'
        }
    });
}


function test_login_wrong() {
    _AJAX({
        'type': 'test',
        'action': 'login',
        'data': {
            'type': 'basic',
            'email': '2',
            'password': 'pass'
        }
    });
}

function test_login_missing() {
    _AJAX({
        'type': 'test',
        'action': 'login',
        'data': {
            'type': 'basic',
            'password': 'pass'
        }
    });
}

function test_login_basic() {
    _AJAX({
        'type': 'test',
        'action': 'login',
        'data': {
            'type': 'basic',
            'email': 'mail@mail.fr',
            'password': 'pass'
        }
    });
}

function test_reset() {
    document.getElementById('test-result-response').innerHTML = '';
}

function signup_reset(type, all = false) {
    for(key in to_reset_signup) {
        document.getElementById('signup-' + type + '-result-' + to_reset_signup[key]).innerHTML = '';
    }
    document.getElementById("signup-firstname-label").innerHTML = '';
    document.getElementById("signup-lastname-label").innerHTML = '';
    document.getElementById("signup-email-label").innerHTML = '';
    document.getElementById("signup-password-label").innerHTML = '';
    if(all) {
        document.getElementById("signup-firstname").value = '';
        document.getElementById("signup-lastname").value = '';
        document.getElementById("signup-email").value = '';
        document.getElementById("signup-password").value = '';
    }
}

function login_reset(type, all = false) {
    for(key in to_reset_login) {
        document.getElementById('login-' + type + '-result-' + to_reset_login[key]).innerHTML = '';
    }
    document.getElementById("login-email-label").innerHTML = '';
    document.getElementById("login-password-label").innerHTML = '';
    if(all) {
        document.getElementById("login-email").value = '';
        document.getElementById("login-password").value = '';
    }
}

function _AJAX(data = default_data, method = "POST", url = url_test) {

    var xhttp = new XMLHttpRequest();

    // xhttp.onload = function () {
    //     console.log(this);
    //     console.log(this.responseText);
    // }

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var res = to_json(this.response);

            if(data.type == 'test') {
                test_reset();
                var temp = "", keys = Object.keys(res);
                for(key in keys) {
                    temp += '<br/>' + keys[key] + " : " + res[keys[key]];
                }
                document.getElementById('test-result-response').innerHTML = temp;
            }
            else {
                data.action == 'signup' && signup_reset(data.data.type);
                data.action == 'login' && login_reset(data.data.type);

                // Typical action to be performed when the document is ready:
                // _process_response(data.action, xhttp.responseText, this.status);
                _process_response(data.action, data.data.type, res, this.status);
            }
        }
        else {
            console.log("readyState => ", this.readyState);
            console.log("status => ", this.status);
        }
    };

    xhttp.open(method, url, true);

    // xhttp.setRequestHeader("Accept", "text/html,application/xhtml+xm…ml;q=0.9,image/webp,*/*;q=0.8");
    // xhttp.setRequestHeader("Accept-Encoding", "gzip, deflate");
    // xhttp.setRequestHeader("Accept-Language", "en-US,en;q=0.5");
    // xhttp.setRequestHeader("Connection", "keep-alive");
    // xhttp.setRequestHeader("Content-Length", "37");
    // xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    // xhttp.setRequestHeader("Host", "localhost");
    // xhttp.setRequestHeader("Origin", "http://localhost");
    // xhttp.setRequestHeader("Referer", "http://localhost/emeka-back/");
    // xhttp.setRequestHeader("Upgrade-Insecure-Requests", "1");
    // xhttp.setRequestHeader("User-Agent", navigator.appVersion);

    xhttp.send(jsonToFormData(data));
}

function _process_response(action, type, response, status) {
    var keys = Object.keys(response);
    for(key in keys) {
        console.log(action + '-' + type + '-result-' + keys[key]);
        document.getElementById(action + '-' + type + '-result-' + keys[key]).innerHTML = response[keys[key]];
    }
    return false;
}

function object_to_formdata(object) {
    var form_data = new FormData();
    for(const key in object) {
        form_data.append(key, object[key]);
    }
    return form_data;
}

function to_json(response) {
    return response ? JSON.parse(response) : {};
}

// STACKOVERFLOW

function buildFormData(formData, data, parentKey) {
    if (data && typeof data === 'object' && !(data instanceof Date) && !(data instanceof File)) {
      Object.keys(data).forEach(key => {
        buildFormData(formData, data[key], parentKey ? `${parentKey}[${key}]` : key);
      });
    } else {
      const value = data == null ? '' : data;
  
      formData.append(parentKey, value);
    }
}
  
function jsonToFormData(data) {
    const formData = new FormData();
  
    buildFormData(formData, data);
  
    return formData;
}

function is_mail(str) {
    return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(str);
}

//

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById("form-signup-basic").addEventListener("submit", function(e) {
        e.preventDefault();
        signup('basic');
    });
    document.getElementById("form-login-basic").addEventListener("submit", function(e) {
        e.preventDefault();
        login('basic');
    });
})