<?php
    function is_loged($id) {
        session_start($id);
        if(!isset($_SESSION['user'])){ return false;}
        if(!isset($_SESSION['user']['loged'])){ return false;}
        return (bool)$_SESSION['user']['loged'];
    }
?>