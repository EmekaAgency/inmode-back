<?php
    $const = array();
    
    $const['inmode']['db_name'] = 'nemzytch_inmode';
    $const['inmode']['users']['inmode'] = array(
        'user' => 'nemzytch_inmode',
        'pass' => 'Y|z@8$z]%68[95HgS^)&y-*6#A_sX&\"G',
    );
    
?>