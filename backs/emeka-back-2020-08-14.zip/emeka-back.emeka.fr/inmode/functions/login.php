<?php
    function login($datas = array()) {
        // echo '<p>login()</p>';
        // echo '<pre>';
        // echo print_r($datas);
        // echo '</pre>';
        $connection = get_connection(
            $GLOBALS['const']['inmode']['users']['inmode']['user'],
            $GLOBALS['const']['inmode']['users']['inmode']['pass'],
            $GLOBALS['const']['inmode']['db_name']
        );
        if(gettype($connection) == 'string') {
            return return_json(array(
                'status' => 'error',
                'reason' => return_error($GLOBALS['_DATABASE_CONNEXTION_ERROR']),
                'message' => $connection
            ));
        }
        $query = htmlspecialchars(
            "SELECT firstname AS firstname, lastname AS lastname, email AS email, role AS role FROM users 
            WHERE 
            `email` = '".$datas['email']."' AND `password` = '".$datas['password']."'"
        );
        $result = $connection->query($query);
        if($result->num_rows > 0) {
            $response = return_json(
                array(
                    'status' => 'success',
                    'message' => 'Success login',
                    'query' => $query,
                    'result' => return_json($result->fetch_assoc())
                )
            );
        }
        else {
            if(is_null($connection->error) || $connection->error == "") {
                $response = return_json(
                    array(
                        'status' => 'error',
                        'message' => return_error($GLOBALS['_NO_USER_WITH_PARAMS']),
                        'query' => $query
                    )
                );
            }
            else {
                $response = return_json(
                    array(
                        'status' => 'error',
                        'message' => $connection->error,
                        'query' => $query
                    )
                );
            }
        }
        $connection->close();
        return print_r($response);
    };
?>