<?php
    function return_json($datas) {
        return json_encode($datas, JSON_UNESCAPED_UNICODE);
    }
?>